Three-shot exemplar package for Baseline-3-shot (seeds 42, 2026, 10086).

Layout: seed<SEED>/<PROGRAM_ID>_<QUERY_PROJECT>/shot<SLOT>_<SHOT_PROJECT>/
            c/<file>.c      (C exemplar)
            cuda/<file>.cu  (paired CUDA exemplar)

Each of the 109 evaluated programs has its own folder per seed; inside it,
shot1..shot3 hold the three paired C-CUDA exemplars sampled for that query
(the query program itself is never selected). manifest.csv lists every
exemplar with its in-package relative path.
